extends State

var can_transition: bool = false

@onready var player1 = get_tree().current_scene.find_child("monge")
@onready var player2 = get_tree().current_scene.find_child("vampire")


func enter():
	super.enter()

	can_transition = false

	animation_player.play("skill")
	await animation_player.animation_finished

	can_transition = true


func teleport():
	var alvo = escolher_alvo()

	if alvo == null:
		return

	owner.global_position = alvo.global_position + Vector2.RIGHT * 40


func escolher_alvo():
	if player1 != null and player2 != null:
		var distancia1 = owner.global_position.distance_to(player1.global_position)
		var distancia2 = owner.global_position.distance_to(player2.global_position)

		if distancia1 <= distancia2:
			return player1
		else:
			return player2

	elif player1 != null:
		return player1

	elif player2 != null:
		return player2

	return null


func transition():
	if can_transition:
		get_parent().change_state("Attack")
		can_transition = false
