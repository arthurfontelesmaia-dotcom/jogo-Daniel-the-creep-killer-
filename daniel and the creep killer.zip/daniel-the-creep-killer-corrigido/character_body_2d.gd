extends CharacterBody2D

const SPEED = 500.0
const JUMP_VELOCITY = -800.0
const GRAVITY = 2000.0
const DANO_ATAQUE = 20

@export var vida_maxima := 100

var vida_atual: int
var barra_vida: Node

@onready var anim_sprite = $AnimatedSprite2D
@onready var attack_pivot = $AttackPivot
@onready var attack_area = $AttackPivot/AttackArea

var atacando = false
var agachado = false
var alvos_atingidos: Array = []


func _ready():
	add_to_group("players")
	vida_atual = vida_maxima
	attack_area.monitoring = false

	# Busca a barra de vida automaticamente dentro do CanvasLayer na cena Main
	var cena = get_tree().current_scene
	if cena:
		barra_vida = cena.find_child("vampireHealth", true, false)

	# Configura a barra de vida inicial com segurança
	if is_instance_valid(barra_vida) and "min_value" in barra_vida:
		barra_vida.min_value = 0
		barra_vida.max_value = vida_maxima
		barra_vida.value = vida_atual
		print("Barra do Vampire conectada com sucesso!")
	else:
		print("AVISO: Nó 'vampireHealth' não foi encontrado no CanvasLayer!")

	# Conexões de Sinais
	attack_area.area_entered.connect(_on_attack_area_area_entered)
	attack_area.body_entered.connect(_on_attack_area_body_entered)
	anim_sprite.animation_finished.connect(_on_animated_sprite_2d_animation_finished)


func _physics_process(delta):
	# GRAVIDADE
	if not is_on_floor():
		velocity.y += GRAVITY * delta

	# MOVIMENTO
	var direction = Input.get_axis("a", "d")

	# AGACHAR
	if Input.is_action_pressed("s") and is_on_floor() and not atacando:
		agachado = true
		velocity.x = 0
	else:
		agachado = false

	# ATAQUE
	if Input.is_action_just_pressed("ataque") and not atacando and not agachado:
		iniciar_ataque()

	# MOVIMENTO
	if atacando or agachado:
		velocity.x = 0
	else:
		if direction != 0:
			velocity.x = direction * SPEED
			if direction < 0:
				anim_sprite.flip_h = true
				attack_pivot.scale.x = -1
			else:
				anim_sprite.flip_h = false
				attack_pivot.scale.x = 1
		else:
			velocity.x = move_toward(velocity.x, 0, SPEED)

		# PULO
		if Input.is_action_just_pressed("w") and is_on_floor():
			velocity.y = JUMP_VELOCITY

	# ANIMAÇÕES
	if atacando:
		pass
	elif agachado:
		anim_sprite.play("crouch")
	elif not is_on_floor():
		if velocity.y < 0:
			anim_sprite.play("jump")
		else:
			anim_sprite.play("fall")
	elif direction != 0:
		anim_sprite.play("walk")
	else:
		anim_sprite.play("stop")

	move_and_slide()


# =========================
# INICIAR ATAQUE
# =========================

func iniciar_ataque():
	atacando = true
	alvos_atingidos.clear()
	velocity.x = 0
	attack_area.monitoring = true
	anim_sprite.play("combo")

	await get_tree().process_frame
	if atacando:
		for body in attack_area.get_overlapping_bodies():
			_on_attack_area_body_entered(body)

		for area in attack_area.get_overlapping_areas():
			_on_attack_area_area_entered(area)


# =========================
# COLISÕES DE ATAQUE
# =========================

func _on_attack_area_area_entered(area):
	if not atacando:
		return

	if area == attack_area or area.owner == self or area.get_parent() == self:
		return

	if area.is_in_group("players") or (area.get_parent() and area.get_parent().is_in_group("players")):
		return

	if area in alvos_atingidos:
		return

	if area.has_method("receber_dano"):
		print(name.to_upper(), " ACERTOU O BOSS!")
		alvos_atingidos.append(area)
		area.receber_dano(DANO_ATAQUE)


func _on_attack_area_body_entered(body):
	if not atacando:
		return

	if body == self or body.is_in_group("players") or body is StaticBody2D or body is TileMap or body is TileMapLayer:
		return

	if body in alvos_atingidos:
		return

	if body.has_method("receber_dano"):
		print(name.to_upper(), " ACERTOU O MINION!")
		alvos_atingidos.append(body)
		body.receber_dano(DANO_ATAQUE)


# =========================
# FIM DO ATAQUE
# =========================

func _on_animated_sprite_2d_animation_finished():
	if anim_sprite.animation == "combo":
		attack_area.monitoring = false
		atacando = false
		alvos_atingidos.clear()


# =========================
# RECEBER DANO E MORRER
# =========================

func receber_dano(dano: int):
	vida_atual -= dano
	vida_atual = max(vida_atual, 0)

	if is_instance_valid(barra_vida) and "value" in barra_vida:
		barra_vida.value = vida_atual

	print("Vida do Vampire: ", vida_atual)

	if vida_atual <= 0:
		morrer()


func morrer():
	print("Vampire morreu!")
	queue_free()
