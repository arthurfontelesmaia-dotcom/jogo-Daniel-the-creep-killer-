extends CharacterBody2D

const VELOCIDADE = 60.0
const DISTANCIA_ATAQUE = 50.0
const DANO = 10

@onready var animation = $AnimatedSprite2D

var player1
var player2
var alvo

var vida = 1
var atacando = false
var pode_atacar = true

func _ready():
	player1 = get_tree().current_scene.find_child("monge", true, false)
	player2 = get_tree().current_scene.find_child("vampire", true, false)

	print("MINION NASCEU!")
	animation.play("idle")


func _physics_process(_delta):
	# Impede que o minion se mova ou mude de animação enquanto ataca
	if atacando:
		return

	alvo = escolher_alvo()

	if alvo == null:
		velocity = Vector2.ZERO
		if animation.animation != "idle":
			animation.play("idle")
		return

	var distancia = global_position.distance_to(alvo.global_position)

	# =========================
	# ATACAR / ESPERAR COOLDOWN
	# =========================
	if distancia <= DISTANCIA_ATAQUE:
		velocity = Vector2.ZERO
		
		if pode_atacar:
			atacar()
		else:
			if animation.animation != "idle":
				animation.play("idle")

	# =========================
	# SEGUIR
	# =========================
	else:
		var direction = alvo.global_position - global_position
		velocity = direction.normalized() * VELOCIDADE

		if velocity.x < 0:
			animation.flip_h = true
		elif velocity.x > 0:
			animation.flip_h = false

		

	move_and_slide()


# =========================
# ESCOLHER ALVO
# =========================
func escolher_alvo():
	# is_instance_valid previne crashes se o player tiver morrido (queue_free)
	var p1_valido = is_instance_valid(player1)
	var p2_valido = is_instance_valid(player2)

	if p1_valido and p2_valido:
		var distancia1 = global_position.distance_to(player1.global_position)
		var distancia2 = global_position.distance_to(player2.global_position)

		if distancia1 <= distancia2:
			return player1
		else:
			return player2

	elif p1_valido:
		return player1
	elif p2_valido:
		return player2

	return null


# =========================
# ATAQUE
# =========================
func atacar():
	atacando = true
	pode_atacar = false
	velocity = Vector2.ZERO


	await get_tree().create_timer(0.2).timeout

	# Crucial: Checa se o minion não foi destruído durante os 0.2 segundos
	if not is_instance_valid(self) or not is_inside_tree():
		return

	# Checa se o alvo ainda existe antes de calcular a distância
	if is_instance_valid(alvo):
		var distancia = global_position.distance_to(alvo.global_position)

		if distancia <= DISTANCIA_ATAQUE:
			if alvo.has_method("receber_dano"):
				print("MINION ACERTOU ", alvo.name)
				alvo.receber_dano(DANO)

	atacando = false

	await get_tree().create_timer(1.0).timeout
	pode_atacar = true


# =========================
# RECEBER DANO
# =========================
# =========================
# RECEBER DANO
# =========================
func receber_dano(dano):
	print("MINION TOMOU HIT E VAI MORRER INSTANTANEAMENTE!")
	morrer()


# =========================
# MORRER
# =========================
func morrer():
	print("MINION MORREU!")
	queue_free()
