extends CharacterBody2D

@export var vida_maxima := 1000
var vida_atual: int

@onready var barra_vida = $"../CanvasLayer/BossHealthBar"
@onready var anim_sprite = $AnimatedSprite2D



func _ready():
	vida_atual = vida_maxima
	
	barra_vida.min_value = 0
	barra_vida.max_value = vida_maxima
	barra_vida.value = vida_atual
	
	anim_sprite.play("idle")


func receber_dano(dano: int):
	vida_atual -= dano
	vida_atual = max(vida_atual, 0)

	barra_vida.value = vida_atual

	print("Vida do Boss: ", vida_atual)
	print("Barra:", barra_vida.value)

	if vida_atual <= 0:
		morrer()


func morrer():
	print("Boss morreu!")
	queue_free()
