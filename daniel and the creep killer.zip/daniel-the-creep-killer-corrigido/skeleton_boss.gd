extends CharacterBody2D

const DANO_ATAQUE := 15
const DISTANCIA_ATAQUE := 100.0
const MARGEM_TOLERANCIA := 30.0 # Previne que o player fuja nos milissegundos do golpe

@export var vida_maxima := 1000
@export var velocidade := 40.0

@onready var animated_sprite = $AnimatedSprite2D
@onready var barra_vida = $"../CanvasLayer/BossHealthBar"

var player1
var player2
var vida_atual: int
var direction: Vector2
var alvo

var atacando := false
var pode_atacar := true


func _ready():
	vida_atual = vida_maxima

	# Interface
	if is_instance_valid(barra_vida):
		barra_vida.min_value = 0
		barra_vida.max_value = vida_maxima
		barra_vida.value = vida_atual



	animated_sprite.play("idle")


func _process(_delta):
	buscar_jogadores()
	alvo = escolher_alvo()

	if alvo == null or atacando:
		direction = Vector2.ZERO
		return

	direction = alvo.global_position - global_position

	# Virar o Sprite para o jogador
	if direction.x < 0:
		animated_sprite.flip_h = true
	elif direction.x > 0:
		animated_sprite.flip_h = false


func _physics_process(delta):
	if atacando or alvo == null:
		velocity = Vector2.ZERO
		return

	var distancia = global_position.distance_to(alvo.global_position)

	# =========================
	# ATACAR OU PERSEGUIR
	# =========================
	if distancia <= DISTANCIA_ATAQUE:
		velocity = Vector2.ZERO
		if pode_atacar:
			atacar()
	else:
		velocity = direction.normalized() * velocidade
		move_and_collide(velocity * delta)
		
		if animated_sprite.sprite_frames.has_animation("walk") and animated_sprite.animation != "walk":
			animated_sprite.play("walk")


# =========================
# LOCALIZAR JOGADORES
# =========================
func buscar_jogadores():
	var cena = get_tree().current_scene
	if cena:
		if not is_instance_valid(player1):
			player1 = cena.find_child("monge", true, false)
			if not player1:
				player1 = cena.find_child("Monge", true, false)

		if not is_instance_valid(player2):
			player2 = cena.find_child("vampire", true, false)
			if not player2:
				player2 = cena.find_child("Vampire", true, false)


func escolher_alvo():
	var p1_valido = is_instance_valid(player1)
	var p2_valido = is_instance_valid(player2)

	if p1_valido and p2_valido:
		var distancia1 = global_position.distance_to(player1.global_position)
		var distancia2 = global_position.distance_to(player2.global_position)
		return player1 if distancia1 <= distancia2 else player2

	elif p1_valido:
		return player1
	elif p2_valido:
		return player2

	return null


# =========================
# SISTEMA DE ATAQUE
# =========================
func atacar():
	atacando = true
	pode_atacar = false
	velocity = Vector2.ZERO

	if animated_sprite.sprite_frames.has_animation("attack"):
		animated_sprite.play("attack")

	# Delay para acertar o golpe (tempo do impacto do soco/golpe)
	await get_tree().create_timer(0.3).timeout

	if not is_instance_valid(self) or not is_inside_tree():
		return

	# Aplica o dano se o player ainda estiver ao alcance
	if is_instance_valid(alvo):
		var distancia = global_position.distance_to(alvo.global_position)
		if distancia <= (DISTANCIA_ATAQUE + MARGEM_TOLERANCIA):
			if alvo.has_method("receber_dano"):
				print("BOSS ACERTOU ", alvo.name.to_upper())
				alvo.receber_dano(DANO_ATAQUE)

	atacando = false

	# Cooldown entre ataques do Boss (1.5 segundos)
	await get_tree().create_timer(1.5).timeout
	pode_atacar = true


# =========================
# DANO E MORTE
# =========================
func receber_dano(dano: int):
	vida_atual -= dano
	vida_atual = max(vida_atual, 0)

	if is_instance_valid(barra_vida):
		barra_vida.value = vida_atual
	

	print("Vida do Boss: ", vida_atual)

	if vida_atual <= 0:
		morrer()


func take_damage():
	receber_dano(2)


func morrer():
	print("Boss morreu!")

	

	var fsm = find_child("FiniteStateMachine")
	if is_instance_valid(fsm):
		fsm.change_state("Death")

	queue_free()
