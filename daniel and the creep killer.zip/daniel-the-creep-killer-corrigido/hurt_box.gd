extends Area2D

func receber_dano(dano: int):
	get_parent().receber_dano(dano)
