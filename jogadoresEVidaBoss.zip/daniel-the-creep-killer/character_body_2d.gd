extends CharacterBody2D

const SPEED = 500.0
const JUMP_VELOCITY = -800.0
const GRAVITY = 2000.0
const DANO_ATAQUE = 20

@onready var anim_sprite = $AnimatedSprite2D
@onready var attack_pivot = $AttackPivot
@onready var attack_area = $AttackPivot/AttackArea

var atacando = false
var agachado = false
var ja_acertou = false


func _ready():

	attack_area.monitoring = false

	# Detecta quando o AttackArea encosta no HurtBox
	attack_area.area_entered.connect(_on_attack_area_area_entered)


func _physics_process(delta):

	# =========================
	# GRAVIDADE
	# =========================

	if not is_on_floor():
		velocity.y += GRAVITY * delta


	# =========================
	# MOVIMENTO
	# =========================

	var direction = Input.get_axis("a", "d")


	# =========================
	# AGACHAR
	# =========================

	if Input.is_action_pressed("s") and is_on_floor() and not atacando:

		agachado = true
		velocity.x = 0

	else:

		agachado = false


	# =========================
	# ATAQUE
	# =========================

	if Input.is_action_just_pressed("ataque") and not atacando and not agachado:

		iniciar_ataque()


	# =========================
	# MOVIMENTO
	# =========================

	if atacando or agachado:

		velocity.x = 0

	else:

		if direction != 0:

			velocity.x = direction * SPEED


			# OLHAR PARA ESQUERDA
			if direction < 0:

				anim_sprite.flip_h = true
				attack_pivot.scale.x = -1


			# OLHAR PARA DIREITA
			else:

				anim_sprite.flip_h = false
				attack_pivot.scale.x = 1


		else:

			velocity.x = move_toward(velocity.x, 0, SPEED)


		# =========================
		# PULO
		# =========================

		if Input.is_action_just_pressed("w") and is_on_floor():

			velocity.y = JUMP_VELOCITY


	# =========================
	# ANIMAÇÕES
	# =========================

	if atacando:

		pass

	elif agachado:

		anim_sprite.play("crouch")

	elif not is_on_floor():

		if velocity.y < 0:

			anim_sprite.play("jump")

		else:

			anim_sprite.play("fall")

	elif direction != 0:

		anim_sprite.play("walk")

	else:

		anim_sprite.play("stop")


	move_and_slide()


# =========================
# INICIAR ATAQUE
# =========================

func iniciar_ataque():

	atacando = true
	ja_acertou = false

	velocity.x = 0

	attack_area.monitoring = true

	anim_sprite.play("combo")


# =========================
# DETECTAR BOSS
# =========================

func _on_attack_area_area_entered(area):

	if not atacando:
		return

	if ja_acertou:
		return

	if area.has_method("receber_dano"):

		print("PLAYER 1 ACERTOU O BOSS!")

		area.receber_dano(DANO_ATAQUE)

		ja_acertou = true


# =========================
# FIM DO ATAQUE
# =========================

func _on_animated_sprite_2d_animation_finished():

	if anim_sprite.animation == "combo":

		attack_area.monitoring = false

		atacando = false
		ja_acertou = false
