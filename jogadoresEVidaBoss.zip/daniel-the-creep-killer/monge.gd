extends CharacterBody2D

const SPEED = 500.0
const JUMP_VELOCITY = -800.0
const GRAVITY = 2000.0
const DANO_ATAQUE = 20

@onready var anim_sprite = $AnimatedSprite2D
@onready var attack_pivot = $AttackPivot
@onready var attack_area = $AttackPivot/AttackArea

var atacando = false
var flying_kick = false
var ja_acertou = false


func _ready():

	attack_area.monitoring = false

	# Detecta quando o AttackArea encosta no HurtBox
	attack_area.area_entered.connect(_on_attack_area_area_entered)


func _physics_process(delta):

	# =========================
	# GRAVIDADE
	# =========================

	if not is_on_floor():

		velocity.y += GRAVITY * delta


	# =========================
	# MOVIMENTO
	# =========================

	var direction = 0


	if Input.is_key_pressed(KEY_LEFT):

		direction = -1

	elif Input.is_key_pressed(KEY_RIGHT):

		direction = 1


	# =========================
	# SOCO
	# =========================

	if Input.is_key_pressed(KEY_J) and is_on_floor() and not atacando:

		iniciar_punch()


	# =========================
	# FLYING KICK
	# =========================

	if Input.is_key_pressed(KEY_J) and not is_on_floor() and not atacando:

		iniciar_flying_kick()


	# =========================
	# MOVIMENTO
	# =========================

	if atacando:

		# Flying kick pode se movimentar

		if flying_kick:

			if direction != 0:

				velocity.x = direction * SPEED


				if direction < 0:

					anim_sprite.flip_h = true
					attack_pivot.scale.x = -1

				else:

					anim_sprite.flip_h = false
					attack_pivot.scale.x = 1

	else:

		if direction != 0:

			velocity.x = direction * SPEED


			if direction < 0:

				anim_sprite.flip_h = true
				attack_pivot.scale.x = -1

			else:

				anim_sprite.flip_h = false
				attack_pivot.scale.x = 1

		else:

			velocity.x = move_toward(velocity.x, 0, SPEED)


		# =========================
		# PULO
		# =========================

		if Input.is_key_pressed(KEY_UP) and is_on_floor():

			velocity.y = JUMP_VELOCITY


	# =========================
	# FIM DO FLYING KICK
	# =========================

	if flying_kick and is_on_floor():

		flying_kick = false
		atacando = false
		ja_acertou = false

		attack_area.monitoring = false

		anim_sprite.play("stop")


	# =========================
	# ANIMAÇÕES
	# =========================

	if flying_kick:

		anim_sprite.play("flying kick")

	elif atacando:

		pass

	elif not is_on_floor():

		if velocity.y < 0:

			anim_sprite.play("jump")

		else:

			anim_sprite.play("fall")

	elif direction != 0:

		anim_sprite.play("walk")

	else:

		anim_sprite.play("stop")


	move_and_slide()


# =========================
# SOCO
# =========================

func iniciar_punch():

	atacando = true
	flying_kick = false
	ja_acertou = false

	velocity.x = 0

	attack_area.monitoring = true

	anim_sprite.play("punch")


# =========================
# FLYING KICK
# =========================

func iniciar_flying_kick():

	atacando = true
	flying_kick = true
	ja_acertou = false

	attack_area.monitoring = true


	if Input.is_key_pressed(KEY_LEFT):

		velocity.x = -SPEED

	elif Input.is_key_pressed(KEY_RIGHT):

		velocity.x = SPEED


	anim_sprite.play("flying kick")


# =========================
# DETECTAR BOSS
# =========================

func _on_attack_area_area_entered(area):

	if not atacando:
		return

	if ja_acertou:
		return

	if area.has_method("receber_dano"):

		print("PLAYER 2 ACERTOU O BOSS!")

		area.receber_dano(DANO_ATAQUE)

		ja_acertou = true


# =========================
# FIM DAS ANIMAÇÕES
# =========================

func _on_animated_sprite_2d_animation_finished():

	if anim_sprite.animation == "punch":

		attack_area.monitoring = false

		atacando = false
		flying_kick = false
		ja_acertou = false


	if anim_sprite.animation == "flying kick":

		# O flying kick termina quando tocar no chão.
		pass
